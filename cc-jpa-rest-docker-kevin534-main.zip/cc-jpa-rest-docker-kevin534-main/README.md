# cc-jpa-rest-docker-kevin534
cc-jpa-rest-docker-kevin534 created by GitHub Classroom

#Je lance mon fichier Dockerfile et mes containers sont déployés avec success dans docker et mes images sont crées .
#Cependant j'ai aussi utilisé l'api generated-request.http pour tester mes différents service en allant dans le package rest puis aller dans l'une des resource puis clicker sur path ,prendre la deuxième option .
# Tout d'abord je commence par persister chenil ensuite personne ,chien et pathologie en utilisant ces commandes suivante:

###
PUT http://localhost:8080/myapp/chenilresource/persist

###
PUT http://localhost:8080/myapp/personneresource/persist

###
PUT http://localhost:8080/myapp/chienresource/persist

###
PUT http://localhost:8080/myapp/patologieresource/persist

# Une fois que j'ai persister mes données dans le database postgres , je procède a des intérogations:

GET http://localhost:8080/myapp/patologieresource/allPatho

<> 2022-04-24T161317.200.json
<> 2022-04-24T140127.200.json
<> 2022-04-24T133213.200.json
<> 2022-04-24T132354.200.json
<> 2022-04-24T130647.200.json
<> 2022-04-24T090637.200.json
<> 2022-04-24T090622.200.json


###
GET http://localhost:8080/myapp/personneresource/allPerson

<> 2022-04-24T133217.200.json
<> 2022-04-24T132400.200.json
<> 2022-04-24T130713.200.json


###
GET http://localhost:8080/myapp/chienresource/allChien

<> 2022-04-24T133224.200.json
<> 2022-04-24T130720.200.json




###
GET http://localhost:8080/myapp/chenilresource/allChenil

<> 2022-04-24T133228.200.json
<> 2022-04-24T132406.200.json
<> 2022-04-24T130727.200.json

###
GET http://localhost:8080/myapp/chenilresource/chenil/1

<> 2022-04-24T162324.200.json
<> 2022-04-24T162315.200.json

###
GET http://localhost:8080/myapp/personneresource/person/3

<> 2022-04-24T162420.200.json
<> 2022-04-24T162413.200.json
###
PUT http://localhost:8080/myapp/personneresource/deleteChienPerson/3

###
GET http://localhost:8080/myapp/personneresource/person/4

<> 2022-04-24T133234.200.json
<> 2022-04-24T130733.200.json
<> 2022-04-24T091607.200.json
<> 2022-04-24T085610.200.json
