package controllers;

import dao.ChenilDao;
import dao.ChienDao;
import dao.PatologieDao;
import dao.PersonDAO;
import entities.*;

import java.util.ArrayList;
import java.util.List;

public class ChenilController {
    List<Chenil> listChenil = new ArrayList<>();

    PersonDAO personDAO = new PersonDAO();
    ChienDao chienDAO = new ChienDao();
    PatologieDao pathologieDao = new PatologieDao();
    ChenilDao chenilDao = new ChenilDao();
    List<Chien> chienList =  new ArrayList<>();

    public void addChenil(){
        ChenilDao chenilDao = new ChenilDao();
        // insert chenil
        Chenil chenil = new Chenil("chenil1");
        Chenil chenil1 = new Chenil("chenil2");


        chenilDao.persist(chenil);
        chenilDao.persist(chenil1);
    }
    public List<Chenil> getList(){
        listChenil = chenilDao.findAll();
        chienList = chienDAO.findAll();
        for (Chenil chenil: listChenil){
            for (Chien chien: chienList){
                if (chien.getChenil_id() == chenil.getId()){
                    chenil.setChienList(chien);
                }
            }
        }
        return listChenil;
    }
    public Chenil getChenilByID(long id){

        Chenil chenil1 = chenilDao.getChenilById(id);

        return chenil1;

    }
}
