package controllers;

import dao.ChenilDao;
import dao.ChienDao;
import dao.PatologieDao;
import dao.PersonDAO;
import entities.Chien;
import entities.Pathologie;
import entities.Personne;

import java.util.ArrayList;
import java.util.List;

public class ChienController {
    List<Chien> listChien = new ArrayList<>();
    List<Personne> listPersonne = new ArrayList<>();
    List<Pathologie> pathologieList = new ArrayList<>();

    PersonDAO personDAO = new PersonDAO();
    ChienDao chienDao = new ChienDao();
    PatologieDao pathologieDao = new PatologieDao();
    ChenilDao chenilDao = new ChenilDao();


    public  void insertChien(){
        Chien chien1 = new Chien("Rex");
        Chien chien2 = new Chien("Boby");
        Chien chien3 = new Chien("Berger Allemand");
        Chien chien4 = new Chien("Max");
        chien1.setChenil_id(chenilDao.findAll().get(0).getId());
        chien1.setPersonne_id(personDAO.findAll().get(0).getPersonne_id());
        chienDao.persist(chien1);
        chien2.setPersonne_id(personDAO.findAll().get(1).getPersonne_id());
        chien2.setChenil_id(chenilDao.findAll().get(0).getId());
        chienDao.persist(chien2);
        chien3.setPersonne_id(personDAO.findAll().get(2).getPersonne_id());
        chien3.setChenil_id(chenilDao.findAll().get(1).getId());
        chienDao.persist(chien3);
        chien4.setPersonne_id(personDAO.findAll().get(3).getPersonne_id());
        chien4.setChenil_id(chenilDao.findAll().get(1).getId());
        chienDao.persist(chien4);
    }

    public List<Chien> getList(){
        listChien = chienDao.findAll();
        pathologieList = pathologieDao.findAll();
        for(Chien item : listChien) {
            for (Pathologie p : pathologieList) {
                if (p.getChien_id() == item.getChien_id()) {
                    item.setListPathologie(p);
                }
                System.out.println(item);
            }
        }
        return listChien;
    }
    public Chien getChienByID(long id){

        Chien chien1 = chienDao.getChienById(id);
        return chien1;

    }
}
