package controllers;
import dao.ChienDao;
import dao.PatologieDao;
import dao.PersonDAO;
import entities.Chien;
import entities.Pathologie;
import entities.Personne;

import java.util.ArrayList;
import java.util.List;
public class PatologieController {
    List<Chien> listChien = new ArrayList<>();
    List<Personne> listPersonne = new ArrayList<>();
    List<Pathologie> pathologieList = new ArrayList<>();

    PersonDAO personDAO = new PersonDAO();
    ChienDao chienDAO = new ChienDao();
    PatologieDao pathologieDao = new PatologieDao();

    public List<Pathologie> getList(){
        pathologieList = pathologieDao.findAll();
        for (Pathologie item:pathologieList
        ) {
            System.out.println(item);
        }

        return pathologieList;
    }

    public void insertPathologie(){

        Chien chien1 = chienDAO.findAll().get(0);
        Chien chien  = chienDAO.findAll().get(1);
        Pathologie pathologie2 = new Pathologie("herpes","virus pour allemand");
        Pathologie pathologie3 = new Pathologie("viral ","virus pour rageux");
        Pathologie pathologie1 = new Pathologie("boudock","virus pour cheval");
        Pathologie pathologie4= new Pathologie("rock ","virus pour berger");


        pathologie1.setChien_id(chien.getChien_id());
        pathologie2.setChien_id(chien1.getChien_id());
        pathologie3.setChien_id(chien.getChien_id());
        pathologie4.setChien_id(chien1.getChien_id());

        pathologieDao.persist(pathologie1);
        pathologieDao.persist(pathologie4);
        pathologieDao.persist(pathologie2);
        pathologieDao.persist(pathologie3);

    }
    public Pathologie getPathologieByID(long id){

        Pathologie pathologie = pathologieDao.getPathologieById(id);
        return pathologie;

    }

    public void deletePathoById(long id) {
        pathologieDao.delete(pathologieDao.findById(id));
    }
}
