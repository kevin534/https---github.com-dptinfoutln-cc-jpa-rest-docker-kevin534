package controllers;

import dao.ChenilDao;
import dao.ChienDao;
import dao.PatologieDao;
import dao.PersonDAO;
import entities.Chien;
import entities.Pathologie;
import entities.Personne;

import java.util.ArrayList;
import java.util.List;

public class PersonneController {
    List<Chien> listChien = new ArrayList<>();
    List<Personne> listPersonne = new ArrayList<>();
    List<Pathologie> pathologieList = new ArrayList<>();

    PersonDAO personDAO = new PersonDAO();
    ChienDao chienDAO = new ChienDao();
    ChenilDao chenilDao = new ChenilDao();
    PatologieDao pathologieDao = new PatologieDao();


    public void insertPersonne(){

        PersonDAO personDAO = new PersonDAO();
        Personne p1 =  new Personne(15,28,"mahomed","gracias");
        Personne p2 =  new Personne(16,38,"hulda","le bon");
        Personne p3 =  new Personne(17,48,"kevin","xavier");
        Personne p4 =  new Personne(18,58,"Martin","Paul");

        personDAO.persist(p1);
        personDAO.persist(p2);
        personDAO.persist(p3);
        personDAO.persist(p4);

    }
    public List<Personne> getList(){
        listChien = chienDAO.findAll();
        listPersonne = personDAO.findAll();

        for(Personne p: listPersonne){
            for(Chien c: listChien){
                if(c.getPersonne_id() == p.getPersonne_id()){
                    p.setChien(c);
                }
            }
        }
        return listPersonne;
    }
    public Personne getPersonByID(long id){

        Personne user = personDAO.findById(id);
        return user;

    }
    public void updatePerson(long id ,String nom , String prenom ){
        Personne user = personDAO.findById(id);
        String[] param = null;
        param[0]=nom;
        param[1]= prenom;
        personDAO.update(user,param);
    }

    public void deleteChienPersonnne(long idPersonne) {

        listChien = chienDAO.findAll();
        listPersonne = personDAO.findAll();
        pathologieList = pathologieDao.findAll();
        for(Personne p: listPersonne){
            for(Chien c: listChien){
                if(c.getPersonne_id() == p.getPersonne_id()){
                    p.setChien(c);
                }
            }
        }

        Personne p = new Personne();
        for(Personne pers: listPersonne){
            if(pers.getPersonne_id() == idPersonne)
                p = pers;
        }
        for(Pathologie patho: pathologieList){
            if (patho.getChien_id() ==p.getChien().getChien_id())
                pathologieDao.delete(patho);
        }
        chienDAO.delete(p.getChien());
    }
}
