package dao;

import entities.Chenil;
import lombok.extern.java.Log;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
@Log
public class ChenilDao implements DAO<Chenil> {

    final EntityManagerFactory emf = Persistence.createEntityManagerFactory("testpostgresqllocal");
    EntityManager entityManager = emf.createEntityManager();

    List<Chenil> listChenil = new ArrayList<>();

    @Override
    public void persist(Chenil entity) {
        try{
            EntityTransaction transac = entityManager.getTransaction();
            transac.begin();
            entityManager.persist(entity);
            transac.commit();

            log.info("Insertion des chenils réussi avec success!!");
        } catch (Exception e) {
            e.printStackTrace();
            log.info("Erreur durant l'insertion des chenils!!");
        }
    }
    @Override
    public List<Chenil> findAll() {
        Query query = entityManager.createQuery("SELECT c FROM Chenil c");
        listChenil = query.getResultList();
        return listChenil;
    }

    public Chenil getChenilById(long id){
        return entityManager.find(Chenil.class, id);
    }

    @Override
    public void update(Chenil chenil, String[] params) {
        chenil.setNom(Objects.requireNonNull(params[0], "Name cannot be null"));
        executeInsideTransaction(entityManager -> entityManager.merge(chenil));
    }




    @Override
    public void delete(Chenil t) {
        executeInsideTransaction(entityManager -> entityManager.remove(t));
    }

    private void executeInsideTransaction(Consumer<EntityManager> action) {
        EntityTransaction tx = entityManager.getTransaction();
        try {
            tx.begin();
            action.accept(entityManager);
            tx.commit();
        }
        catch (RuntimeException e) {
            tx.rollback();
            throw e;
        }
    }
    @Override
    public Optional<Chenil> findByIdentifiant(long id) {
        return Optional.ofNullable(entityManager.find(Chenil.class, id));
    }



}
