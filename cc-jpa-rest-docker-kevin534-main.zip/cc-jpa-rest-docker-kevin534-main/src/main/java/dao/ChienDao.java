package dao;

import entities.Chien;
import entities.Personne;
import lombok.extern.java.Log;

import javax.persistence.*;
import java.util.*;
import java.util.function.Consumer;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
@Log
 public class ChienDao implements DAO<Chien> {

    final EntityManagerFactory emf = Persistence.createEntityManagerFactory("testpostgresqllocal");
    EntityManager entityManager = emf.createEntityManager();

    List<Chien> listChien = new ArrayList<>();

    @Override
    public void persist(Chien entity) {
        try{
            EntityTransaction transac = entityManager.getTransaction();
            transac.begin();
            entityManager.persist(entity);
            transac.commit();

            log.info("Insertion des chiens réussi avec success!!");
        } catch (Exception e) {
            e.printStackTrace();
            log.info("Erreur durant l'insertion des chiens!!");
        }
    }


    @Override
    public List<Chien> findAll() {
        Query query = entityManager.createQuery("SELECT c FROM Chien c");
        listChien = query.getResultList();
        return listChien;
    }

    public Chien getChienById(long id){
        return entityManager.find(Chien.class, id);
    }


    @Override
    public void update(Chien user, String[] params) {
        user.setNom(Objects.requireNonNull(params[0], "Name cannot be null"));
        executeInsideTransaction(entityManager -> entityManager.merge(user));
    }


    @Override
    public void delete(Chien t) {
        executeInsideTransaction(entityManager -> entityManager.remove(t));
    }

    private void executeInsideTransaction(Consumer<EntityManager> action) {
        EntityTransaction tx = entityManager.getTransaction();
        try {
            tx.begin();
            action.accept(entityManager);
            tx.commit();
        }
        catch (RuntimeException e) {
            tx.rollback();
            throw e;
        }
    }
    @Override
    public Optional<Chien> findByIdentifiant(long id) {
        return Optional.ofNullable(entityManager.find(Chien.class, id));
    }




}
