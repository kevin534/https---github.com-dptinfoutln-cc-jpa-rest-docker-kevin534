package dao;
import java.util.List;
import java.util.Optional;

public interface DAO<E> {
    Optional<E> findByIdentifiant(long id);
    void persist(E entity);
    List<E> findAll();

    void update(E t, String[] params);

    void delete(E t);

}