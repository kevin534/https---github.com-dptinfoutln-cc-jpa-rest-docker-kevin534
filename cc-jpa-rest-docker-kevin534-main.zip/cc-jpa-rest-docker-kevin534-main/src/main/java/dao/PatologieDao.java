package dao;

import entities.Chien;
import entities.Pathologie;
import entities.Personne;
import lombok.extern.java.Log;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

@Log
public class PatologieDao implements DAO<Pathologie> {

    final EntityManagerFactory emf = Persistence.createEntityManagerFactory("testpostgresqllocal");
    EntityManager entityManager = emf.createEntityManager();

    @Override
    public void persist(Pathologie entity) {
        try{
            EntityTransaction transac = entityManager.getTransaction();
            transac.begin();
            entityManager.persist(entity);
            transac.commit();

            log.info("Insertion des pathologies réussi avec success!!");
        } catch (Exception e) {
            e.printStackTrace();
            log.info("Erreur durant l'insertion des pathologies!!");
        }
    }

    @Override
    public List<Pathologie> findAll() {
        Query query = entityManager.createQuery("SELECT p FROM Pathologie p");
        return query.getResultList();
    }

    public Pathologie getPathologieById(long id){
        return entityManager.find(Pathologie.class, id);
    }


    @Override
    public void update(Pathologie user, String[] params) {
        user.setNom(Objects.requireNonNull(params[0], "Name cannot be null"));
        user.setDescription(Objects.requireNonNull(params[0], "Name cannot be null"));
        executeInsideTransaction(entityManager -> entityManager.merge(user));
    }

    @Override
    public void delete(Pathologie t) {
        executeInsideTransaction(entityManager -> entityManager.remove(t));
    }


    private void executeInsideTransaction(Consumer<EntityManager> action) {
        EntityTransaction tx = entityManager.getTransaction();
        try {
            tx.begin();
            action.accept(entityManager);
            tx.commit();
        }
        catch (RuntimeException e) {
            tx.rollback();
            throw e;
        }
    }
    @Override
    public Optional<Pathologie> findByIdentifiant(long id) {
        return Optional.ofNullable(entityManager.find(Pathologie.class, id));
    }

    public Pathologie findById(long id) {
        return (entityManager.find(Pathologie.class, id));
    }


}
