package dao;

import entities.Personne;
import lombok.extern.java.Log;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;

@Log
public class PersonDAO implements DAO<Personne> {

    final EntityManagerFactory emf = Persistence.createEntityManagerFactory("testpostgresqllocal");
    EntityManager entityManager = emf.createEntityManager();
    private String findAll = "select * from Personne";

    @Override
    public void persist(Personne entity) {
        try{
            EntityTransaction transac = entityManager.getTransaction();
            transac.begin();
            entityManager.persist(entity);
            transac.commit();

            log.info("Insertion des personnes réussi avec success!!");
        } catch (Exception e) {
            e.printStackTrace();
            log.info("Erreur durant l'insertion des personnes!!");
        }

    }

    @Override
    public List<Personne> findAll() {
        Query query = entityManager.createQuery("SELECT p FROM Personne p");
        return query.getResultList();
    }
    @Override
    public void update(Personne user, String[] params) {
        user.setNom(Objects.requireNonNull(params[0], "Name cannot be null"));
        user.setPrenom(Objects.requireNonNull(params[1], "surname cannot be null"));
        executeInsideTransaction(entityManager -> entityManager.merge(user));
    }

    @Override
    public void delete(Personne t) {
        executeInsideTransaction(entityManager -> entityManager.remove(t));
    }

    private void executeInsideTransaction(Consumer<EntityManager> action) {
        EntityTransaction tx = entityManager.getTransaction();
        try {
            tx.begin();
            action.accept(entityManager);
            tx.commit();
        }
        catch (RuntimeException e) {
            tx.rollback();
            throw e;
        }
    }
    @Override
    public Optional<Personne> findByIdentifiant(long id) {
        return Optional.ofNullable(entityManager.find(Personne.class, id));
    }
    public Personne findById(long id) {
        return entityManager.find(Personne.class, id);
    }


}
