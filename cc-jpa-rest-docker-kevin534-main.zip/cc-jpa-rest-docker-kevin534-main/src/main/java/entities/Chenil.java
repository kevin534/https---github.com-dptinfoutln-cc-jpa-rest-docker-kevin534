package entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
@Entity
public class Chenil implements Serializable {
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    @Column(name = "chenil_id")
    private long id;
    @Column(name = "nom")
    private String nom;
    @OneToMany
    @JoinColumn(name="chenil_id", referencedColumnName="chenil_id")
    private List<Chien> chienList;

    public Chenil(String nom) {
        this.nom = nom;
    }

    public Chenil() {

    }

    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public List<Chien> getChienList() {
        return chienList;
    }

    public void setChienList(Chien chien) {
        this.chienList.add(chien);
    }

    @Override
    public String toString() {
        return "Chenil{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", chienList=" + chienList +
                '}';
    }
}
