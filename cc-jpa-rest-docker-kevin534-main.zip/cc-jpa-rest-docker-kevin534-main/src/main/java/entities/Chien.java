package entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name="chien")
public class Chien implements Serializable {
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    @Column (name = "chien_id")
    private long chien_id;
    @Column (name = "nom", nullable = false)
    private String nom;

    @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true)
    @JoinColumn(name="chien_id", referencedColumnName="pathologie_id")
    private List<Pathologie> listPathologie;
    @Column(name = "chenil_id")
    private long chenil_id;

    @Column(name = "personne_id")
    private long personne_id;


    //Constructors, getters and setters removed for brevity

    public Chien() {
    }

    public long getChenil_id() {
        return chenil_id;
    }

    public void setChenil_id(long chenil_id) {
        this.chenil_id = chenil_id;
    }

    public Chien(String nom) {
        this.nom = nom;
    }

    public long getChien_id() {
        return chien_id;
    }

    public void setChien_id(long id) {
        this.chien_id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public List<Pathologie> getListPathologie() {
        return listPathologie;
    }

    public void setListPathologie(Pathologie patho) {
        this.listPathologie.add(patho);
    }

    /*public Personne getPersonne() {
        return personne;
    }

    public void setPersonne(Personne personne) {
        this.personne = personne;
    }*/

    public long getPersonne_id() {
        return personne_id;
    }

    public void setPersonne_id(long personne_id) {
        this.personne_id = personne_id;
    }

    @Override
    public String toString() {
        return "Chien{" +
                "id=" + chien_id +
                ", nom='" + nom + '\'' +
                ", chenil_id=" + chenil_id +
                ", personne_id=" + personne_id+
                ", listPathologie=" + listPathologie +
                '}';
    }
}