package entities;
import com.fasterxml.jackson.annotation.*;
import lombok.*;
import lombok.experimental.FieldDefaults;
import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings ("ALL")
@FieldDefaults (level = AccessLevel.PRIVATE)
@NoArgsConstructor //needed by JPA
@ToString
@Getter
@Setter

@JsonInclude(JsonInclude.Include.NON_EMPTY)


@Entity
@Table(name = "pathologie")
public class Pathologie implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "pathologie_id", nullable = false)
    private long pathologie_id;

    @Column(name = "nom", nullable = false)
    private String nom;
    @Column(name = "description", nullable = false)
    private String description;

    @Column(name = "chien_id")
    private long chien_id;

    public Pathologie( String nom, String description) {
        this.nom = nom;
        this.description = description;
    }

    public long getChien_id() {
        return chien_id;
    }
    public void setChien_id(long chien_id) {
        this.chien_id = chien_id;
    }

    public long getPathologie_id() {
        return pathologie_id;
    }

    public void setPathologie_id(long pathologie_id) {
        this.pathologie_id = pathologie_id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Pathologie{" +
                "pathologie_id=" + pathologie_id +
                ", nom='" + nom + '\'' +
                ", description='" + description + '\'' +
                ", chien_id=" + chien_id +
                '}';
    }
}