package entities;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.*;
import lombok.experimental.FieldDefaults;

import javax.persistence.*;
import java.io.Serializable;

@FieldDefaults (level = AccessLevel.PRIVATE)
@NoArgsConstructor //needed by JPA

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT,use = JsonTypeInfo.Id.NAME)

@Entity

@Table(uniqueConstraints ={
        @UniqueConstraint(name = "CoupleNomEtPrenom", columnNames = { "nom", "prenom" })})

public class Personne implements Serializable {
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    @Column(name = "personne_id")
    private long personne_id;
    @Column (name = "identifiant", nullable = false)
    private long identifiant;
    @Column(name = "age", nullable = false)
    private int age;
    @Column(name = "nom", nullable = false)
    private String nom;
    @Column(name = "prenom", nullable = false)
    private String prenom;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="chien_id", referencedColumnName="personne_id")
    private Chien chien;

 public Personne(long identifiant ,int age, String nom,String prenom) {
        this.identifiant = identifiant;
        this.age = age;
        this.nom = nom ;
        this.prenom = prenom;

    }
    public long getIdentifiant() {
        return identifiant;
    }

    public void setIdentifiant(long identifiant) {
        this.identifiant = identifiant;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }
    public Chien getChien() {
        return chien;
    }

    public void setChien(Chien chien) {
        this.chien = chien;
    }

    public long getPersonne_id() {
        return personne_id;
    }

    public void setPersonne_id(long id) {
        this.personne_id = id;
    }

    @Override
    public String toString() {
        return "Personne{" +
                "id=" + personne_id +
                ", identifiant=" + identifiant +
                ", age=" + age +
                ", nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", chien=" + chien +
                '}';
    }
}