package rest;

import controllers.ChenilController;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import serialisationJson.Json;

/**
 * Root resource (exposed at "myresource" path)
 */

@Path("chenilresource")
public class ChenilResource {
    private ChenilController controller = new ChenilController();
    private Json json = new Json();
    @PUT
    @Path ("persist")
    public void AddChenil()  {

     controller.addChenil();

    }

    @GET
    @Path("allChenil")
    @Produces(MediaType.APPLICATION_JSON)
    public String getListChenil() {
        String asToString = json.doSerialisationChenil(controller.getList());
        return asToString;
    }
    @GET
    @Path("chenil/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String GetChenilByID(@PathParam ("id") long id) throws NotFoundException{
        String asToString = json.doSerialisationChenilById(controller.getChenilByID(id));
        return asToString;
    }

}
