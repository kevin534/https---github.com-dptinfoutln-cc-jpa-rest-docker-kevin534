package rest;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import controllers.ChienController;
import controllers.PersonneController;
import dao.ChienDao;
import dao.PersonDAO;
import entities.Chien;
import entities.Personne;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import dao.PersonDAO;
import entities.Personne;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import serialisationJson.Json;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("chienresource")
public class ChienResource {
    private ChienController controller = new ChienController();
    private Json json = new Json();
    @PUT
    @Path ("persist")
    public void AddChien()  {
        controller.insertChien();
    }

    @GET
    @Path("allChien")
    @Produces(MediaType.APPLICATION_JSON)
    public String getListPerson() {
        String asToString = json.doSerialisationChien(controller.getList());
        return asToString;
    }


    @GET
    @Path("chien/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String GetChienByID(@PathParam ("id") long id) throws NotFoundException{
        String asToString = json.doSerialisationChienById(controller.getChienByID(id));
        return asToString;
    }
}
