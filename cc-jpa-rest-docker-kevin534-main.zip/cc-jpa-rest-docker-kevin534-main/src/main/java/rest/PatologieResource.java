package rest;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import controllers.PatologieController;
import dao.PatologieDao;
import dao.PersonDAO;
import entities.Pathologie;
import entities.Personne;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import dao.ChienDao;
import dao.PersonDAO;
import entities.Chien;
import entities.Personne;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import serialisationJson.Json;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Path("patologieresource")
public class PatologieResource {

    PatologieController patologieController = new PatologieController();
    Json json = new Json();
    @PUT
    @Path ("persist")
    public void AddPatahologie()  {
        patologieController.insertPathologie();
    }

    @PUT
    @Path ("deletePatho/{id}")
    public void deletePatahologie(@PathParam("id") long id){
        patologieController.deletePathoById(id);
    }
    @GET
    @Path("allPatho")
    @Produces(MediaType.APPLICATION_JSON)
    public String getListPatho() {
        String asToString = json.doSerialisationPatho(patologieController.getList());
        return asToString;
    }
    @GET
    @Path("pathologie/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String GetPathologieByID(@PathParam ("id") long id) throws NotFoundException{
        String asToString = json.doSerialisationPathologieById(patologieController.getPathologieByID(id));
        return asToString;
    }


}
