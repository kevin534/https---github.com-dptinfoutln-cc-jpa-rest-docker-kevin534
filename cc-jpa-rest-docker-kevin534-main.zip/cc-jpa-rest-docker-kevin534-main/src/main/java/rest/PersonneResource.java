package rest;

import controllers.PersonneController;
import dao.ChienDao;
import dao.PersonDAO;
import entities.Chien;
import entities.Personne;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.java.Log;
import serialisationJson.Json;

import java.util.ArrayList;
import java.util.List;

@Log
@Path("personneresource")
public class PersonneResource {

    private PersonDAO personDAO;
    private ChienDao chienDao;
    private List<Personne> listPersonne=  new ArrayList<>();
    private List<Chien> listChien = new ArrayList<>();
    private PersonneController controller = new PersonneController();
    private Json json=  new Json();

    @PUT
    @Path("persist")
    public void AddPerson()  {
     controller.insertPersonne();
     System.out.println("persist personne working!!");
    }
    @GET
    @Path("person/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String GetPersonByID(@PathParam ("id") long id) throws NotFoundException{
        String asToString = json.doSerialisationPersonneById(controller.getPersonByID(id));
        return asToString;
    }
    @PUT
    @Path("updatePerson")
    public void updatePerson( @QueryParam("id") long id,
                              @QueryParam("nom") String nom,
                              @QueryParam("prenom") String prenom){

        controller.updatePerson(id, nom, prenom);
        System.out.println("update is ok!");
    }
    @PUT
    @Path("deleteChienPerson/{idPersonne}")
    public void deleteChien( @PathParam("idPersonne") long idPersonne){
        controller.deleteChienPersonnne(idPersonne);

    }


    @GET
    @Path("allPerson")
    @Produces(MediaType.APPLICATION_JSON)
    public String getListPerson() {
        String asToString = json.doSerialisationPersonne(controller.getList());
    return asToString;
    }


}
