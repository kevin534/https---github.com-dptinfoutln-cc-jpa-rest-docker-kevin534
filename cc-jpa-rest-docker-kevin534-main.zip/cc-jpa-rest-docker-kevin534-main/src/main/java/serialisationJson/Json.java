package serialisationJson;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import entities.Chenil;
import entities.Chien;
import entities.Pathologie;
import entities.Personne;
import lombok.extern.java.Log;

import java.util.List;
@Log
public class Json {

    private String string;

    public String doSerialisationPatho(List<Pathologie> listPatho){
        String asToString = null;
        ObjectMapper objectMapper = new ObjectMapper()
                .setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY)
                .enable(SerializationFeature.INDENT_OUTPUT)
                .findAndRegisterModules();
        try {
            asToString = objectMapper.writeValueAsString(listPatho);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return asToString;
    }
    public String doSerialisationChien(List<Chien> lisChien){
        String asToString = null;
        ObjectMapper objectMapper = new ObjectMapper()
                .setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY)
                .enable(SerializationFeature.INDENT_OUTPUT)
                .findAndRegisterModules();
        try {
            asToString = objectMapper.writeValueAsString(lisChien);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return asToString;
    }
    public String doSerialisationChienById(Chien chien){

        String asToString= null;
        ObjectMapper objectMapper = new ObjectMapper()
                .setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY)
                .enable(SerializationFeature.INDENT_OUTPUT)
                .findAndRegisterModules();
        try {
            asToString = objectMapper.writeValueAsString(chien);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return asToString;
    }
    public String doSerialisationPersonneById(Personne personne){
        String asToString = null;
        ObjectMapper objectMapper = new ObjectMapper()
                .setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY)
                .enable(SerializationFeature.INDENT_OUTPUT)
                .findAndRegisterModules();
        try {
            asToString = objectMapper.writeValueAsString(personne);
            log.info("Insertion des personnes  avec success!!");
            log.info(objectMapper.writeValueAsString("SUCCESS!!"));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            log.info("Insertion des personnes échoués !!");
        }
        return  asToString;
    }

    public String doSerialisationPersonne(List<Personne> listPersonne){
        String asToString = null;
        ObjectMapper objectMapper = new ObjectMapper()
                .setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY)
                .enable(SerializationFeature.INDENT_OUTPUT)
                .findAndRegisterModules();
        try {
            asToString = objectMapper.writeValueAsString(listPersonne);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return asToString;
    }

    public String doSerialisationChenil(List<Chenil> list) {
        String asToString = null;
        ObjectMapper objectMapper = new ObjectMapper()
                .setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY)
                .enable(SerializationFeature.INDENT_OUTPUT)
                .findAndRegisterModules();
        try {
            asToString = objectMapper.writeValueAsString(list);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return asToString;
    }
    public String doSerialisationChenilById(Chenil chenil){
        String asToString = null;
        ObjectMapper objectMapper = new ObjectMapper()
                .setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY)
                .enable(SerializationFeature.INDENT_OUTPUT)
                .findAndRegisterModules();
        try {
            asToString = objectMapper.writeValueAsString(chenil);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return asToString;
    }
    public String doSerialisationPathologieById(Pathologie pathologie){
        String asToString = null;
        ObjectMapper objectMapper = new ObjectMapper()
                .setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY)
                .enable(SerializationFeature.INDENT_OUTPUT)
                .findAndRegisterModules();
        try {
            asToString = objectMapper.writeValueAsString(pathologie);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return asToString;
    }
}
